

  <?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?> 
  <div class="alert alert-success" role="alert">
      <?php echo e(session('status')); ?>

  </div>
  <?php endif; ?>   

<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <div class="row">
            <div class="col-md-6">
            <h4 class="card-title"><span>Data Dealer</span></h4>
            </div>
            <div class="col-md-6 text-right">
                <a  href="/add-dealer" class="btn btn-sm btn-success"><i class="material-icons">add</i> Tambah Dealer</a>
            </div>
        </div>
        
      </div>

      

    <div class="card-body">
    
    <form class="navbar-form col-sm-6" action="/cari" method="get">
                
      <div class="input-group no-border">
        <?php if(!request()->get('keyword')): ?>
        <input type="text" name="keyword" class="form-control col-sm-10" placeholder="Masukan kata kunci pencarian" id="search">
        <?php else: ?>
        <input type="text" name="keyword" value="<?php echo e(request()->keyword); ?>"class="form-control col-sm-10" placeholder="Masukan kata kunci pencarian" id="search">
        <?php endif; ?>
        <button type="submit" class="btn btn-white btn-round btn-just-icon">
        <i class="material-icons">search</i>
        <div class="ripple-container"></div>
        </button> 
      </div>                          
    </form>

    <div class="card-body table-responsive">
      <table class='table table-hover'>
			<thead class="text-primary">
				<tr>
					<th>No</th>
					<th>Kode</th>
					<th>Nama Dealer</th>
					<th>Alamat</th>
          <th>Kota</th>
          <th>Pos</th>
          <th>DDS</th>
          <th>Depo</th>
          <th>Rayon</th>
          <th>Opsi</th>
				</tr>
			</thead>
			<tbody>
      <?php 
        $i=1 
      ?>
      <?php $__currentLoopData = $dealer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($index + $dealer->firstItem()); ?></td>
					<td><?php echo e($d->kode_dealer); ?></td>
					<td><?php echo e($d->nama_dealer); ?></td>
					<td><?php echo e($d->alamat); ?></td>
          <td><?php echo e($d->kota); ?></td>
          <td><?php echo e($d->kodepos); ?></td>
          <td><?php echo e($d->dds); ?></td>
          <td><?php echo e($d->depo); ?></td>
          <td><?php echo e($d->rayon); ?></td>
          <td>
          <div class="btn-group">
            <a href="dealer/<?php echo e($d->id); ?>/edit" class="badge badge-sm badge-round badge-info"><i class="material-icons">drive_file_rename_outline</i></a>
            <form action="dealer/<?php echo e($d->id); ?>" method="post" >    
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>  
              <!-- <a href="dealer/<?php echo e($d->id); ?>" class="badge badge-round badge-danger" onclick="return confirm('Yakin menghapus?');"><i class="material-icons" >delete_outline</i></a> -->
              <button type="submit" name="submit" class="badge badge-sm badge-round badge-danger" onclick="return confirm('Yakin menghapus?');"><i class="material-icons" >delete_outline</i></button>
            </form>          
          </div>
          </td>
				</tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
    <?php echo e($dealer->links()); ?>

    </div>
    
    </div>

    </div>
  </div>
</div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
  'activePage' => 'dealer', 
  'titlePage' => __('Dealer')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/dealer/index.blade.php ENDPATH**/ ?>