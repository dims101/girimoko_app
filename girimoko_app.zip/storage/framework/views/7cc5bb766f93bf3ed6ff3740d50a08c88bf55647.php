<footer class="footer">
    <div class="container">
        <!-- <nav class="float-left">
        <ul>
            <li>
            <a href="#">
                <?php echo e(__('Creative Tim')); ?>

            </a>
            </li>
            <li>
            <a href="#">
                <?php echo e(__('About Us')); ?>

            </a>
            </li>
            <li>
            <a href="#">
                <?php echo e(__('Blog')); ?>

            </a>
            </li>
            <li>
            <a href="#">
                <?php echo e(__('Licenses')); ?>

            </a>
            </li>
        </ul>
        </nav> -->
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>
        <?php echo e(__(" Modified by")); ?>

      <a href="#" target="_blank"><?php echo e(__(" DDM Project")); ?></a>.
      <?php echo e(__(" Designed by")); ?>

        <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a>.
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>