<div class="sidebar" data-color="azure" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="/" class="simple-text logo-normal">
      <?php echo e(__('AWB Tracking System')); ?>

    </a>
	<!-- <a href="#"><img style="width: 100px;" src="/material/img/girimoko.jpeg" class="simple-text logo-normal"></a> -->
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'summary' ? ' active' : ''); ?>">
        <a class="nav-link" href="/summary">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Summary')); ?></p>
        </a>
      </li>
      <?php if(auth()->user()->level == "admin" or auth()->user()->level == "Super Admin"): ?> 
      <!-- <li class="nav-item<?php echo e($activePage == 'dashboard_admin' ? ' active' : ''); ?>">
        <a class="nav-link" href="/home">
          <i class="material-icons">admin_panel_settings</i>
            <p><?php echo e(__('Panel Admin')); ?></p>
        </a>
      </li> -->
      <li class="nav-item<?php echo e($activePage == 'register' ? ' active' : ''); ?>">
        <a class="nav-link" href="/register">
          <i class="material-icons">add</i>
            <p><?php echo e(__('Tambah pengguna')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'dealer' ? ' active' : ''); ?>">
        <a class="nav-link" href="/dealer">
          <i class="material-icons">home</i>
            <p><?php echo e(__('Dealer')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'import_excel' ? ' active' : ''); ?>">
        <a class="nav-link" href="/awb/excel">
          <i class="material-icons">upload_file</i>
            <p><?php echo e(__('Import File Excel')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <li class="nav-item<?php echo e($activePage == 'delivery' ? ' active' : ''); ?>">
        <a class="nav-link" href="/delivery">
          <i class="material-icons">local_shipping</i>
            <p><?php echo e(__('DDS Delivery Report')); ?></p>
        </a>
      </li>
      <!-- <li class="nav-item<?php echo e($activePage == 'notifications' ? ' active' : ''); ?>">
        <a class="nav-link" href="">
          <i class="material-icons">notifications</i>
          <p><?php echo e(__('Notifications')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'language' ? ' active' : ''); ?>">
        <a class="nav-link" href="">
          <i class="material-icons">language</i>
          <p><?php echo e(__('RTL Support')); ?></p>
        </a>
      </li> -->
   
    </ul>
  </div>
</div><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>