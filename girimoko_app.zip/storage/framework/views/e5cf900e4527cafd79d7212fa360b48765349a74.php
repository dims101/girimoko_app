

  <?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?> 
  <div class="alert alert-success" role="alert">
      <?php echo e(session('status')); ?>

  </div>
  <?php endif; ?>   

<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title"><span>Tambah Dealer</span></h4>
      </div>

    <div class="card-body">
    <br>
    <form method="POST" action="dealer/store">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="kode_dealer" class=""><?php echo e(__('Kode Dealer')); ?></label>
            </div>
            <div class="col-md-6">
                <input id="kode_dealer" type="text" class="form-control <?php $__errorArgs = ['kode_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_dealer" value="<?php echo e(old('kode_dealer')); ?>" required autocomplete="kode_dealer" autofocus>
                <?php $__errorArgs = ['kode_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="nama_dealer" class=""><?php echo e(__('Nama Dealer')); ?></label>
            </div>
            <div class="col-md-6">
                <input id="nama_dealer" type="text" class="form-control <?php $__errorArgs = ['nama_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_dealer" value="<?php echo e(old('nama_dealer')); ?>" required autocomplete="nama_dealer">
                <?php $__errorArgs = ['nama_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>   

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="alamat" class=""><?php echo e(__('Alamat')); ?></label>
            </div>
            <div class="col-md-6">
                <textarea id="alamat" type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" value="<?php echo e(old('alamat')); ?>" required autocomplete="alamat"></textarea>
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="provinsi" class=""><?php echo e(__('Provinsi')); ?></label>
            </div>
            <div class="col-md-6">
                <input id="provinsi" type="text" class="form-control <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="provinsi" value="<?php echo e(old('provinsi')); ?>" required autocomplete="provinsi">
                <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="kota" class=""><?php echo e(__('Kota')); ?></label>
            </div>
            <div class="col-md-6">
                <input id="kota" type="text" class="form-control <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kota" value="<?php echo e(old('kota')); ?>" required autocomplete="kota">
                <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="kodepos" class=""><?php echo e(__('Kode Pos')); ?></label>
            </div>
            <div class="col-md-6">
                <input id="kodepos" type="number" class="form-control <?php $__errorArgs = ['kodepos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kodepos" value="<?php echo e(old('kodepos')); ?>" required autocomplete="kodepos">
                <?php $__errorArgs = ['kodepos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="dds" class=""><?php echo e(__('DDS')); ?></label>
            </div>
            <div class="col-md-6">
                <select name="dds" id="dds"  class="form-control <?php $__errorArgs = ['dds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">--Pilih--</option>
                    <?php $__currentLoopData = $dds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->dds); ?>"><?php echo e($d->dds); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['dds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="depo" class=""><?php echo e(__('Depo')); ?></label>
            </div>
            <div class="col-md-6">
                <select name="depo" id="depo"  class="form-control <?php $__errorArgs = ['depo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </select>
                <?php $__errorArgs = ['depo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="form-group row">
            <div class="col-md-4 col-form-label">
                <label for="rayon" class=""><?php echo e(__('Rayon')); ?></label>
            </div>
            <div class="col-md-6">
            <select name="rayon" id="rayon"  class="form-control <?php $__errorArgs = ['rayon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                </select>
                <?php $__errorArgs = ['rayon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>
        </div>
    </div>
    <div class="form-group row mb-2 text-right">
      <div class="col-md-6 offset-md-5">
          <button type="submit" class="btn btn-success">
              <?php echo e(__('Simpan')); ?>

          </button>
          <a href="/dealer" class="btn btn-warning">Kembali</a>
      </div>
    </div>
    </form>
    
    </div>

    </div>
  </div>
</div>
<script>
//     $(function () {
//     $('#dds').on('change', function () {
//         axios.post("<?php echo e(route('selected')); ?>", {dds: $(this).val()})
//             .then(function (response) {
//                 $('#depo').empty();

//                 $.each(response.data, function (depo) {
//                     $('#depo').append(new Option(depo))
//                 })
//             });
//     });
// });
$(function () {
    $.ajaxSetup({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
    });

    $('#dds').on('change', function () {
        $.ajax({
            url: "<?php echo e(route('selected')); ?>",
            method: 'POST',
            dataType : 'json',
            data: {dds: $(this).val(),
            _token : "<?php echo e(Session::token()); ?>"},
            success: function (response) {
                $('#depo').empty();
                $('#depo').append(new Option('--Pilih--',''));
                $.each(response, function (depo,depo) {
                    $('#depo').append(new Option(depo,depo))
                })
            },
            error: function(jqXHR, status, err){
                alert(jqXHR.responseText);
            }
        })
    });
    $('#depo').on('change', function () {
        $.ajax({
            url: "<?php echo e(route('rayon')); ?>",
            method: 'POST',
            dataType : 'json',
            data: {depo: $(this).val(),
            _token : "<?php echo e(Session::token()); ?>",
            dds: $('#dds').val(),
            },
            success: function (response) {
                $('#rayon').empty();
                $('#rayon').append(new Option('--Pilih--',''));
                $.each(response, function (rayon,rayon) {
                    $('#rayon').append(new Option(rayon,rayon))
                })
            },
            error: function(jqXHR, status, err){
                alert(jqXHR.responseText);
            }
        })
    });
});
</script>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
  'activePage' => 'dealer', 
  'titlePage' => __('Dealer')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/dealer/tambah.blade.php ENDPATH**/ ?>