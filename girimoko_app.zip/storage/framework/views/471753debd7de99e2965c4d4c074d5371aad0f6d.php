

<?php $__env->startSection('content'); ?>        
<?php if(session('status')): ?>
  <div class="alert alert-success" role="alert">
      <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>       
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <div class="row">
          <div class="col-md-6">
            <h4 class="card-title"><span><?php echo e($awbs->dds); ?></span> - <span><?php echo e($awbs->depo); ?> (<?php echo e($awbs->rayon); ?>)</span></h4>          
          </div>
          <div class="col-md-6 text-right">
              <h5 class="card-title"><?php echo e($awbs->status == null ? 'Sedang dikirim' : 'Telah diterima'); ?> <?php echo e($isdelay); ?></h5>
          </div>
        </div>
      </div>
      <div class="card-body">
      <div class="row">
      <div class="col-md-6">
          <div class="card-body mt-1">
              <table class="table-borderless">
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Nomor AWB")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->no_awb); ?></h5></td>
              </tr>
              <tr><td></td></tr><tr><td></td></tr><tr><td></td></tr>
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Nama Dealer")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->nama_dealer); ?></h5></td>
              </tr>
              <tr><td></td></tr><tr><td></td></tr><tr><td></td></tr>
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Tanggal Kirim")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(date("l, d-m-Y", strtotime($awbs->tanggal_ds))); ?></h5></td>
              </tr>
              <tr><td></td></tr><tr><td></td></tr><tr><td></td></tr>
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Tanggal Terima")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->tanggal_terima != null ? date("l, d-m-Y", strtotime($awbs->tanggal_terima)) : "-"); ?></h5></td>
              </tr>
              </table>
          </div>
      </div>

      <div class="col-md-6">
          <div class="card-body mt-1">
              <table class="table-borderless">              
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Waktu Terima")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->waktu_terima != null ? $awbs->waktu_terima : "-"); ?></h5></td>
              </tr>
              <tr><td></td></tr><tr><td></td></tr><tr><td></td></tr>
              <tr>
                <td><h5 class="card-subtitle text-muted  "><?php echo e(__(" Penerima")); ?></h5></td>
                <td><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->penerima !=   null ? $awbs->penerima : "-"); ?></h5></td>
              </tr>
              <tr><td></td></tr><tr><td></td></tr><tr><td></td></tr>
              <tr>
                <td style="vertical-align: top;"><h5 class="card-subtitle text-muted  "><?php echo e(__(" Keterangan")); ?></h5></td>
                <td style="vertical-align: top;"><h5 class="card-subtitle text-muted  ">&nbsp;<?php echo e(__(":")); ?>&nbsp;</h5></td>
                <td><h5 class="card-subtitle text-muted  "><?php echo e($awbs->keterangan); ?></h5></td>
              </tr>
              </table>
          </div>
      </div>

      </div>
      </div> 

      <div class="card-body table-responsive">
        <table class="table table-hover">
        <!-- <table class="table table-borderless"> -->
          <thead class="text-primary">
            <th>No.</th>
            <th>No. Performa</th>
            <th>Total Koli</th>
            <th>Tipe Produk</th>
          </thead>
          <tbody>
          <?php if(count($proformas) != null): ?>
            <?php $__currentLoopData = $proformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proforma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($proforma->no_proforma); ?></td>
                <td><?php echo e($proforma->koli); ?></td>
                <td><?php echo e($proforma->tipe); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <tr>
              <td colspan="5"><center>AWB sedang dikirim</center></td>
            </tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      
      <div class="text-right pb-3 pr-4">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            Lihat bukti Awb
          </button>
          <?php if(auth()->user()->level == "admin" or auth()->user()->level == "Super Admin"): ?> 
            <a href="/delivery/edit/<?php echo e($awbs->no_awb); ?>" class="btn btn-success">Edit</a>
          <?php endif; ?>
          <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning">Kembali</a>
      </div>
    </div>
  </div> 
</div>  
<!-- BaseModal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e($awbs->no_awb); ?> - <?php echo e($awbs->nama_dealer); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
        <?php if(empty($awbs->foto_awb)): ?>
          <img src="<?php echo e(asset('bukti_awb')); ?>/default-image.jpg" class="img-fluid" alt="">
        <?php else: ?>
          <img src="<?php echo e(asset('bukti_awb')); ?>/<?php echo e($awbs->foto_awb); ?>" class="img-fluid" alt="">
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>
<script>
  $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
  'activePage' => 'delivery', 
  'titlePage' => __('DDS Delivery Report')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/delivery/detail.blade.php ENDPATH**/ ?>