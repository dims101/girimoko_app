

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary row">
                    <div class="col-md-6">
                        <h4 class="card-title"><span><?php echo e(__('Edit data')); ?></span></h4>
                    </div>
                    
                </div>

                <div class="card-body">
                    <?php if(session('message')): ?> 
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>  
                    <form method="POST" action="/delivery/store" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="no_awb" class=""><?php echo e(__('No AWB')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($awbs->no_awb); ?>" id="no_awb" type="text" class="form-control <?php $__errorArgs = ['no_awb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>

                                    <?php $__errorArgs = ['no_awb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="nama_dealer" class=""><?php echo e(__('Nama Dealer')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($nama_dealer); ?>" id="nama_dealer" type="text" class="form-control <?php $__errorArgs = ['nama_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>

                                    <?php $__errorArgs = ['nama_dealer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="no_kendaraan" class=""><?php echo e(__('No. Kendaraan')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($pengiriman->no_kendaraan); ?>" id="no_kendaraan" type="text" class="form-control" name="no_kendaraan" required autofocus>
                                </div>                                
                                    <?php $__errorArgs = ['no_kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> 
                            
                            <div class="row ml-1">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="foto" class=""><?php echo e(__('Foto AWB')); ?></label>
                                </div>
                                <div class="col-md-6 text-md-right">                                
                                    <?php if($pengiriman->foto_awb<>null): ?>
                                    <a href="/bukti_awb/<?php echo e($pengiriman->foto_awb); ?>" target="_blank">
                                    <img src="/bukti_awb/<?php echo e($pengiriman->foto_awb); ?>" alt="" class="img-thumbnail">
                                    </a>
                                    <?php endif; ?>
                                    <input name="foto_awb" id="foto" type="file" class="form-control" >
                                </div>                                
                                    <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> 
                            
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="tgl_kirim" class=""><?php echo e(__('Tanggal Kirim')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e(date('d/m/Y', strtotime($awbs->tanggal_ds))); ?>" id="tgl_kirim" type="text" class="form-control <?php $__errorArgs = ['tgl_kirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>

                                    <?php $__errorArgs = ['tgl_kirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="tanggal_terima" class=""><?php echo e(__('Tanggal Terima')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($pengiriman->tanggal_terima); ?>" id="tanggal_terima" type="date" class="form-control <?php $__errorArgs = ['tanggal_terima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_terima" disabled >

                                    <?php $__errorArgs = ['tanggal_terima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="waktu_terima" class=""><?php echo e(__('Waktu Terima')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($pengiriman->waktu_terima); ?>" id="waktu_terima" type="time" class="form-control" name="waktu_terima" DISABLED >
                                </div>                                
                                    <?php $__errorArgs = ['waktu_terima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>   
                            
                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="penerima" class=""><?php echo e(__('Penerima')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <input value="<?php echo e($pengiriman->penerima); ?>" id="penerima" type="text" class="form-control" name="penerima" required >
                                </div>                                
                                    <?php $__errorArgs = ['penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> 

                            <div class="form-group row">
                                <div class="col-md-4 col-form-label text-md-left">
                                    <label for="keterangan" class=""><?php echo e(__('Keterangan')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <textarea  id="keterangan" type="text" class="form-control" name="keterangan" required ><?php echo e($awbs->keterangan); ?></textarea>
                                </div>                                
                                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> 
                            
                            <div class="row">
                                <div class="col-md-10">
                                    <div class="form-group row mb-2 text-left">
                                        <div class="col-md-12 offset-md-5">
                                            <?php if($pengiriman->id != null): ?>
                                            <input type="hidden" name="id" value="<?php echo e($pengiriman->id); ?>">
                                            <input type="hidden" name="no_awb" value="<?php echo e($awbs->no_awb); ?>">
                                            <input type="hidden" name="kode_dealer" value="<?php echo e($awbs->kode_dealer); ?>">
                                            <button type="submit" class="btn btn-success">
                                                <?php echo e(__('Simpan')); ?>

                                            </button>
                                            <?php endif; ?>
                                            <a href="/delivery/detail/<?php echo e($awbs->no_awb); ?>" class="btn btn-warning">Kembali</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app' ,[
  'activePage' => 'delivery', 
  'titlePage' => __('Edit data AWB')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\girimoko_app\resources\views/delivery/edit.blade.php ENDPATH**/ ?>