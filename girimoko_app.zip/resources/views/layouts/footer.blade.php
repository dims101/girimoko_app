<footer class="footer">
    <div class="container">
        <!-- <nav class="float-left">
        <ul>
            <li>
            <a href="#">
                {{ __('Creative Tim') }}
            </a>
            </li>
            <li>
            <a href="#">
                {{ __('About Us') }}
            </a>
            </li>
            <li>
            <a href="#">
                {{ __('Blog') }}
            </a>
            </li>
            <li>
            <a href="#">
                {{ __('Licenses') }}
            </a>
            </li>
        </ul>
        </nav> -->
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>
        {{__(" Modified by")}}
      <a href="#" target="_blank">{{__(" DDM Project")}}</a>.
      {{__(" Designed by")}}
        <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a>.
        </div>
    </div>
</footer>